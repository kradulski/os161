#define EM_CPU		EM_MIPS
