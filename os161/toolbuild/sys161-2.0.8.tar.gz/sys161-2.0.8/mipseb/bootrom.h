int bootrom_fetch(uint32_t offset, uint32_t *val);
const uint32_t *bootrom_map(uint32_t offset);
