#ifndef METER_H
#define METER_H

void meter_init(const char *pathname);

#endif /* METER_H */
