extern uint32_t bus_ramsize;
extern char *ram;

